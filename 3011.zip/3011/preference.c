//
// Created by George on 12/1/2018.
//

#include "preference.h"
#include "typedefs_and_general_functions.h"
struct Preference_t{
  Preference preference;
};