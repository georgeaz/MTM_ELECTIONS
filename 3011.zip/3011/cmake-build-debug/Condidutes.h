//
// Created by User on 30/11/2018.
//HBD Nassim & Violet

#ifndef UNTITLED1_CONDIDUTES_H
#define UNTITLED1_CONDIDUTES_H

#include "citizen.h"



#endif //UNTITLED1_CONDIDUTES_H
